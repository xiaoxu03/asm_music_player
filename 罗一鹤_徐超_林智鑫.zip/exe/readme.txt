直接使用命令行运行exe文件夹中可执行文件即可。
若需要编译，请使用RadASM v2.2.4打开src中的MusicPlayer.rap编译运行。